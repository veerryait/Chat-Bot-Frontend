function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
    if (input == "Hello") {
        return "Hello there, What's your name?";
    } else if (input == "Veer") {
        return "Hello Veer, Robo Doc this side, do you need any help?";
    } else if (input == "yes") {
        return "What are the symptoms?";
    } else if (input == "Gulabi Dil!") {
        return "Do you have heart problems?";
    } else if (input == "cough") {
        return "Do you have any other problems?";
    } else if (input == "fever") {
        return "high or low?";
    } else if (input == "high") {
        return "Would you like to go to a doctor or would prefer some medications?";
    } else if (input == "medications") {
        return "You may take Paracetamol or Dolo 650. Some steam may be helpul too. It would be better if you quarintined yourself.";
    } else if (input == "low") {
        return "Would you like to go to a doctor or would prefer some medications?";
    } else if (input == "doctor") {
        return "These are the doctors in your locality. Please click or copy paste them in your browser. ";
    } else if (input == "Request initiation") {
        return "Processing...";
    } else {
        return "Try again";
    }
}